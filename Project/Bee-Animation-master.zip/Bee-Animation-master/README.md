Bee Animation using OpenGL
